import React from 'react';
import './App.css';
import Searchbox from './component/Searchbox'

function App() {
  return (
    <div className = "container">
        <Searchbox />
    </div>
  );
}

export default App;
